package HW7;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class TCPServer {

    static FileInputStream fr;
    static List<File> lst;
    // т.к. фабрика, сделаем ограничение на 8 пользователей
    static ExecutorService executeIt = Executors.newFixedThreadPool(8);

    TCPServer() throws FileNotFoundException { }

    /**
     *     args[0] - путь к файлу
     *     args[1] - порт
     *     @autor Ризо Андрей БПИ194
     */
    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(1234);

            // используем путь из аргументов
            if (args.length >= 1){
                try{
                    String path = args[0];
                    File dir = new File(path);
                    lst = new ArrayList<>();
                    for ( File file : dir.listFiles() ){
                        if ( file.isFile() )
                            lst.add(file);
                    }
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            }
            else{
                System.out.println("Please input path as first argumant and try again");
                return;
            }
            if(lst.size() == 0){
                System.out.println("No files found in this derictory");
                return;
            }

            // используем сокет из аргуметнов
            if(args.length >= 2){
                try{
                    server = new ServerSocket(Integer.parseInt(args[1]));
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            }
            else{
                System.out.println("Default 1234 socket will be used");
            }

            while (!server.isClosed()) {
                Socket client = server.accept();
                executeIt.execute(new MonoThreadClientHandler(client));
                System.out.print("Client accepted" + "\n");
            }
            executeIt.shutdown();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static class MonoThreadClientHandler implements Runnable {

        Socket client;
        public MonoThreadClientHandler(Socket socket){
            client = socket;
        }

        /**
         *     новый поток на каждого нового пользователя
         */
        @Override
        public void run(){
            try{
                // создаем потоки для общения с клиентом
                DataInputStream in = new DataInputStream(client.getInputStream());
                DataOutputStream out = new DataOutputStream(client.getOutputStream());

                // отправляем список доступных файлов клиенту
                String startInfo = "List of files:" + "\n";
                for(int i = 0; i < lst.size(); i++){
                    startInfo += i+1 + ") " + lst.get(i) + "\n";
                }

                // отправляем клиенту список файлов
                out.writeUTF(startInfo);

                int number = 1;
                try{
                    number = Integer.parseInt(in.readUTF());
                    long size = lst.get(number - 1).length();
                    out.writeUTF("File size: " + size + "\n" + "Download file y / n ?");
                    String answer = in.readUTF();
                }
                catch (Exception ex){
                    System.out.println("Exception while choosing file");
                    return;
                }


                // отправляем файл клиенту
                fr = new FileInputStream(lst.get(number - 1));
                byte[] b = new byte[100_000];
                fr.read(b, 0, b.length);
                OutputStream os = client.getOutputStream();
                os.write(b, 0, b.length);
            }
            catch (Exception ex){
                ex.printStackTrace();
            }
        }
    }
}