package HW7;

import java.io.*;
import java.net.*;
import java.util.Scanner;


class TCPClient {
    /**
     *     args[0] - хост
     *     args[1] - порт
     *     args[2] - путь к файлу
     *     @autor Ризо Андрей БПИ194
     */
    public static void main(String[] args) throws Exception{

        if(args.length < 2){
            System.out.println("Enter host and port as arguments and try again \n Closing program...");
            return;
        }

        // создаем и инициализируем сокет
        File outputFile;
        Socket socket;
        try{
            socket = new Socket(args[0], Integer.parseInt(args[1]));
            outputFile = new File(args[2]);
        }
        catch (Exception ex){
            System.out.println("Connection problems \nClosing program...");
            return;
        }

        Scanner sc = new Scanner(System.in);
        BufferedReader br =new BufferedReader(new InputStreamReader(System.in));
        DataOutputStream output = new DataOutputStream(socket.getOutputStream());
        DataInputStream input = new DataInputStream(socket.getInputStream());

        // получаем от сервера список доступных файлов
        String info = input.readUTF();
        System.out.println(info);
        System.out.println("Select file from the list, it will be downloaded to your directory");

        // передаем серверу ответ с номером нужного файла
        String fileNumber = sc.nextLine();
        output.writeUTF(fileNumber);

        // получаем вопрос от сервера
        String question = input.readUTF();
        System.out.println(question);

        // отправляем ответ на вопрос серверу
        String answer = sc.nextLine();
        if(!answer.equals("y")){
            System.out.println("You declined download");
            return;
        }
        output.writeUTF(answer);

        // читаем и записываем файл
        FileOutputStream fr = new FileOutputStream(outputFile);
        byte[] b = new byte[100_000];
        InputStream is = socket.getInputStream();
        is.read(b, 0, b.length);
        fr.write(b,0,b.length);
    }
}