package HW;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class HWTest {

    @org.junit.jupiter.api.Test
    void test_toString(){
        Innovator a1 = new Innovator(1);
        assertEquals("InnovatorMartian (Integer:NoNameMartian)", a1.toString());
    }

    @org.junit.jupiter.api.Test
    void tets_addChildren(){
        Innovator a1 = new Innovator(23456);
        a1.addChildren(new Innovator(345));
        assertEquals(true, a1.hasChildWithValue(345));
    }

    @org.junit.jupiter.api.Test
    void test_getChildren(){
        Innovator a1 = new Innovator("father");
        Innovator b1 = new Innovator("son1");
        Innovator b2 = new Innovator("son2");
        Innovator b3 = new Innovator("son3");
        a1.addChildren(b1);
        b2.setParent(a1);
        b3.setParent(a1);
        ArrayList<Martian> list = new ArrayList<>();
        list.add(b1);
        list.add(b2);
        list.add(b3);
        assertEquals(list, a1.getChildren());
    }

    @org.junit.jupiter.api.Test
    void test_setValue(){
        Innovator a1 = new Innovator("father");
        a1.setValue("notFatherAtAll");
        assertEquals("notFatherAtAll", a1.getValue());
    }

    @org.junit.jupiter.api.Test
    void test_setChildren(){
        Innovator a1 = new Innovator("father");
        Innovator b1 = new Innovator("son1");
        Innovator b2 = new Innovator("son2");
        Innovator b3 = new Innovator("son3");
        ArrayList<Martian> list = new ArrayList<>();
        list.add(b1);
        list.add(b2);
        list.add(b3);
        a1.setChildren(list);
        assertEquals(list, a1.getChildren());
    }

    @org.junit.jupiter.api.Test
    void test_getOffsprings(){
        Innovator a1 = new Innovator("father");
        Innovator b1 = new Innovator("son1");
        Innovator b2 = new Innovator("son2");
        Innovator b3 = new Innovator("son3");
        Innovator c1 = new Innovator("grandson1");
        Innovator c2 = new Innovator("grandson2");
        Innovator c3 = new Innovator("grandson3");

        b1.addChildren(c1);
        b2.addChildren(c2);
        b3.addChildren(c3);
        ArrayList<Martian> list = new ArrayList<>();
        list.add(b1);
        list.add(b2);
        list.add(b3);
        a1.setChildren(list);
        list.add(c1);
        list.add(c2);
        list.add(c3);
        ArrayList<Martian> lst = new ArrayList<>();
        assertEquals(list, a1.getOffsprings(lst));
    }

    @Test
    void test_CreateConsercative(){
        Innovator a1 = new Innovator("father");
        Innovator b1 = new Innovator("son1");
        Innovator b2 = new Innovator("son2");
        Innovator b3 = new Innovator("son3");
        Innovator c1 = new Innovator("grandson1");
        Innovator c2 = new Innovator("grandson2");
        Innovator c3 = new Innovator("grandson3");

        b1.addChildren(c1);
        b2.addChildren(c2);
        b3.addChildren(c3);
        ArrayList<Martian> list = new ArrayList<>();
        list.add(b1);
        list.add(b2);
        list.add(b3);
        a1.setChildren(list);
        Conservative cons = new Conservative(null, a1);
        assertEquals("ConservatorMartian (String:NoNameMartian)", cons.toString());
    }

    @Test
    void test_setChildrenCons(){
        Innovator a1 = new Innovator("father");
        Conservative cons = new Conservative(null, a1);
        assertEquals(false, cons.setChildren(null));
    }

    @Test
    void test_setParentCons(){
        Innovator a1 = new Innovator("father");
        Conservative cons = new Conservative(null, a1);
        assertEquals(false, cons.setParent(a1));
    }

    @Test
    void test_deleteChildrenCons(){
        Innovator a1 = new Innovator("father");
        Conservative cons = new Conservative(null, a1);
        assertEquals(false, cons.deleteChildren(null));
    }

    @Test
    void test_printConsercativeTree(){
        Innovator a1 = new Innovator("father");
        Innovator b1 = new Innovator("son1");
        Innovator b2 = new Innovator("son2");
        Innovator b3 = new Innovator("son3");
        Innovator c1 = new Innovator("grandson1");
        Innovator c2 = new Innovator("grandson2");
        Innovator c3 = new Innovator("grandson3");

        b1.addChildren(c1);
        b2.addChildren(c2);
        b3.addChildren(c3);
        ArrayList<Martian> list = new ArrayList<>();
        list.add(b1);
        list.add(b2);
        list.add(b3);
        a1.setChildren(list);
        Conservative cons = new Conservative(null, a1);
        Tree t = new Tree(cons);
        t.print();
    }


    @Test
    void test_printInnovatorTree(){
        Innovator a1 = new Innovator("father");
        Innovator b1 = new Innovator("son1");
        Innovator b2 = new Innovator("son2");
        Innovator b3 = new Innovator("son3");
        Innovator c1 = new Innovator("grandson1");
        Innovator c2 = new Innovator("grandson2");
        Innovator c3 = new Innovator("grandson3");

        b1.addChildren(c1);
        b2.addChildren(c2);
        b3.addChildren(c3);
        ArrayList<Martian> list = new ArrayList<>();
        list.add(b1);
        list.add(b2);
        list.add(b3);
        a1.setChildren(list);
        Tree t = new Tree(a1);
        t.print();
    }

    @Test
    void test_getParentConservative(){
        Innovator a1 = new Innovator("father");
        Innovator b1 = new Innovator("son1");
        Innovator b2 = new Innovator("son2");
        Innovator b3 = new Innovator("son3");
        Innovator c1 = new Innovator("grandson1");
        Innovator c2 = new Innovator("grandson2");
        Innovator c3 = new Innovator("grandson3");

        b1.addChildren(c1);
        b2.addChildren(c2);
        b3.addChildren(c3);
        ArrayList<Martian> list = new ArrayList<>();
        list.add(b1);
        list.add(b2);
        list.add(b3);
        a1.setChildren(list);
        Conservative cons = new Conservative(null, a1);
        assertEquals(null, cons.getParent());
    }

    @Test
    void test_hasChildWithValueConservative(){
        Innovator a1 = new Innovator("father");
        Innovator b1 = new Innovator("son1");
        Innovator b2 = new Innovator("son2");
        Innovator b3 = new Innovator("son3");
        Innovator c1 = new Innovator("grandson1");
        Innovator c2 = new Innovator("grandson2");
        Innovator c3 = new Innovator("grandson3");

        b1.addChildren(c1);
        b2.addChildren(c2);
        b3.addChildren(c3);
        ArrayList<Martian> list = new ArrayList<>();
        list.add(b1);
        list.add(b2);
        list.add(b3);
        a1.setChildren(list);
        Conservative cons = new Conservative(null, a1);
        assertEquals(true, cons.hasChildWithValue("son3"));
    }
}