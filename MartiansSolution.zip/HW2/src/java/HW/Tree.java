package HW;

import java.util.ArrayList;

public class Tree {

    private Martian Mar;

    public Tree(Martian mar){
        Mar = mar;
    }

    // строит дерево Mar
    public void print(){
        ArrayList ts = new ArrayList();
        Mar.printTree(0, ts);
    }

}
