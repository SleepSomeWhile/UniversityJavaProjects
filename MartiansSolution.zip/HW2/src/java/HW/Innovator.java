package HW;

import java.util.ArrayList;

public class Innovator<T> extends Martian<T>{

    public String Name = "NoNameMartian";

    private T Value;

    private Martian Parent;

    private ArrayList<Martian> Children = new ArrayList<>();

    private ArrayList<Martian> Offsprings = new ArrayList<>();

    @Override
    public boolean setChildren(ArrayList<Martian> children){
        if(children.size() < 1){
            return false;
        }
        // метод добавит тех детей, которые пройдут проверку в addChildren
        for(int i = 0; i < children.size(); i++){
            this.addChildren(children.get(i));
        }
        return true;
    }

    @Override
    public boolean addChildren(Martian mar){
        // проверка на совместимость типов т.к. в одном дереве(семье) не может быть марсиан с разными типами
        if(this.getValue().getClass().getSimpleName() != mar.getValue().getClass().getSimpleName()){
            return false;
        }
        // проверка, чтобы не сделать дедушкой самому себе
        if(this.getRoot().equals(mar) || this.getRoot().getChildren().contains(mar)){
            return false;
        }
        // нужно удалить у прошлого родителя mar из списка детей
        if(mar.getParent() != null){
            mar.getParent().deleteChildren(mar);
        }
        if (mar.getParent() != this){
            mar.setParent(this);
        }
        if(this.getChildren().contains(mar)){
            return true;
        }
        Children.add(mar);
        return true;
    }

    @Override
    public boolean deleteChildren(Martian mar){
        return Children.remove(mar);
    }

    @Override
    public ArrayList<Martian> getChildren(){
        return Children;
    }

    @Override
    public boolean hasChildWithValue(T value){
        for(int i = 0; i < Children.size(); i++){
            if(Children.get(i).getValue().equals(value)){
                return true;
            }
        }
        return false;
    }

    @Override
    public T getValue(){
        return Value;
    }

    @Override
    public  Martian getParent() {
        return Parent;
    }

    public boolean setValue(T value){
        if(this.getValue().getClass().getSimpleName() == value.getClass().getSimpleName()){
            Value = value;
            return true;
        }
        return false;
    }

    @Override
    public boolean setParent(Martian mar) {
        if(mar.getRoot().getChildren().contains(this) || mar.getRoot().equals(this)){
            return false;
        }
        if(mar.getValue().getClass().getSimpleName() == this.getValue().getClass().getSimpleName()){
            // удаляем у старого родителя ссылку на этого марсианина
            if(this.getParent() != null){
                Parent.deleteChildren(this);
            }
            Parent = mar;
            if(!Parent.getChildren().contains(this)){
                Parent.addChildren(this);
            }
            return true;
        }
        return false;
    }

    public ArrayList<Martian> getOffsprings(ArrayList<Martian> list){
        if(Children != null){
            list.addAll(Children);
            for(int i = 0; i < Children.size(); i++){
                Children.get(i).getOffsprings(list);
            }
        }
        return list;
    }

    // выводит в консоль дерево с корнем в this
    @Override
    public void printTree(int level, ArrayList<Martian> list){
        String str = "";
        for(int i = 0; i < level; i++){
            str += " ";
        }
        System.out.println(str + this.toString());
        if(Children != null){
            list.addAll(Children);
            for(int i = 0; i < Children.size(); i++){
                Children.get(i).printTree(level + 3,list);
            }
        }
        return;
    }


    public Innovator(T value){
        Value = value;
    }

    @Override
    public String toString(){
        return "InnovatorMartian " + "(" +
                getValue().getClass().getSimpleName().toString() + ":" + Name + ")";
    }

    @Override
    public Martian<T> getRoot(){
        Martian<T> i = this;
        while(i.getParent() != null){
            i = this.getParent().getRoot();
        }
        return i;
    }
}
