package HW;

import java.util.ArrayList;

public class Conservative<T> extends Martian<T>{

    final T Value;

    final String Name;

    final ArrayList<Martian> Children;

    final Martian Parent;

    @Override
    public Martian getParent() {
        return Parent;
    }

    @Override
    public ArrayList<Martian> getChildren() {
        return Children;
    }

    @Override
    public boolean addChildren(Martian mar) {
        return false;
    }

    // возвращает всех родственников ниже в дереве (дети, внуки и т.д.)
    @Override
    public ArrayList<Martian> getOffsprings(ArrayList<Martian> list) {
        if(Children != null){
            list.addAll(Children);
            for(int i = 0; i < Children.size(); i++){
                Children.get(i).getOffsprings(list);
            }
        }
        return list;
    }

    @Override
    public boolean hasChildWithValue(T value) {
        for(int i = 0; i < Children.size(); i++){
            if(Children.get(i).getValue() == value){
                return true;
            }
        }
        return false;
    }

    @Override
    public T getValue() {
        return Value;
    }

    // возвращает корень дерева
    @Override
    public Martian<T> getRoot() {
        Martian<T> i = this;
        while(i.getParent() != null){
            i = this.getParent().getRoot();
        }
        return i;
    }

    public boolean deleteChildren(Martian mar){
        return false;
    }

    @Override
    public boolean setChildren(ArrayList<Martian> children) {
        return false;
    }

    @Override
    public boolean setParent(Martian mar) {
        return false;
    }

    // рекурсивно строит дерево консерваторов, основываясь на поддереве иннвоаторов с корнем в parent
    public Conservative(Conservative<T> con, Innovator<T> parent) {
        Parent = con;
        Value = parent.getValue();
        Name = parent.Name;
        Children = new ArrayList<Martian>();

        for(int i = 0; i < parent.getChildren().size(); i++){
            Innovator<T> child = (Innovator<T>) parent.getChildren().get(i);
            Children.add(new Conservative<T>(this, child));
        }
    }

    // выводит в консоль дерево с корнем в this
    @Override
    public void printTree(int level, ArrayList<Martian> list){
        String str = "";
        for(int i = 0; i < level; i++){
            str += " ";
        }
        System.out.println(str + this.toString());
        if(Children != null){
            list.addAll(Children);
            for(int i = 0; i < Children.size(); i++){
                Children.get(i).printTree(level + 3,list);
            }
        }
        return;
    }

    @Override
    public String toString(){
        return "ConservatorMartian " + "(" +
                getValue().getClass().getSimpleName().toString() + ":" + Name + ")";
    }

}
