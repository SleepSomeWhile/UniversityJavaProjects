package HW;

import java.util.ArrayList;

public abstract class Martian<T> {

    private Martian Parent;

    private T Value;

    private ArrayList<Martian> Children;

    public abstract Martian getParent();

    public abstract ArrayList<Martian> getChildren();

    public abstract boolean addChildren(Martian mar);

    public abstract ArrayList<Martian> getOffsprings(ArrayList<Martian> list);

    public abstract void printTree(int level, ArrayList<Martian> list);

    public abstract boolean hasChildWithValue(T value);

    public abstract T getValue();

    public abstract Martian<T> getRoot();

    public abstract boolean deleteChildren(Martian mar);

    public abstract boolean setChildren(ArrayList<Martian> children);

    public abstract boolean setParent(Martian mar);
}


