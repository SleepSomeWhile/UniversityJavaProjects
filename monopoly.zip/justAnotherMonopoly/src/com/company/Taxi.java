package com.company;

import java.util.Random;

public class Taxi extends Cell {
    public static Random rand = new Random();

    public String toString(){
        return "You are on a TaxiCell";
    }

    public void OnStep(Player p, char[][] field){
        int range = rand.nextInt(6) + 1;
        System.out.println("You are shifted forward by " + range + " cells");
        p.Move(range, field);
    }
}