package com.company;

/**
 * @author <a href="mailto:aarizo@edu.hse.ru">Rizo Andrei 194</>
 */
public class Cell {

}
