package com.company;

public class PenaltyCell extends Cell {

    public String toString(){
        return "You are on a PenaltyCell";
    }

    public void OnStep(Player p, double coef){
        System.out.println("You have payed a penalty " + p.money*coef);
        p.money -= p.money*coef;
        p.moneySpend += p.money*coef;
    }
}
