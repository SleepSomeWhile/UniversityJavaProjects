package com.company;

public class EmptyCell extends Cell {
    public String toString(){
        return "You are on an EmptyCell \nJust relax here";
    }
}
