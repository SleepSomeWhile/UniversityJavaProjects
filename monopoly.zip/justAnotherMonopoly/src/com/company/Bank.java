package com.company;

import java.util.Random;
import java.util.Scanner;


public class Bank extends Cell {
    public static Random rand = new Random();
    public String toString(){
        return "You are on a BankCell";
    }

    public Boolean IsNum(String str){
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public void OnStep(Player p, double coef){
        if(p.debt > 0){
            System.out.println("You have payed your debt " + p.debt);
            p.money -= p.debt;
            p.debt = 0;
        }
        else{
            if(p.moneySpend == 0){
                System.out.println("You have not spend any money yet.");
                return;
            }
            Scanner in = new Scanner(System.in);
            System.out.println("You are in the bank office. Would you like to get a credit? Input how many you want to get or ’No’");
            String answer = in.nextLine();
            while(!IsNum(answer) && !answer.equals("No")){
                System.out.println("Wrong input print how many you want to get or ’No’");
                answer = in.nextLine();
            }
            if(answer.equals("No")){
                System.out.println("ok. No debt was taken");
            }
            else{
                double d = Double.parseDouble(answer);
                if(d > coef*p.moneySpend){
                    System.out.println("You are not allowed to take so many. Bye");
                }
                else{
                    p.money += d;
                    p.debt += d;
                    System.out.println("You have take a debt for " + d);
                }
            }
        }
    }
}
