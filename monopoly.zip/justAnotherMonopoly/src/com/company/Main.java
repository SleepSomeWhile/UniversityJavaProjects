package com.company;

import java.util.Random;

/**
 * @author <a href="mailto:aarizo@edu.hse.ru"> Andrei Rizo</a>
 */


public class Main {
    // checks height from args
    static boolean CheckHeight(String[] args){
        try{
            if( Integer.parseInt(args[0]) > 30 || Integer.parseInt(args[0]) < 6) {
                System.out.println("Wrong height value: ( can be only [6, 30] )");
                return false;
            }
        }
        catch (Exception ex){
            System.out.println("Wrong height value: " + ex.getMessage());
            return false;
        }
        return true;
    }

    // checks width from args
    static boolean CheckWidth(String[] args){
        try{
            if( Integer.parseInt(args[1]) > 30 || Integer.parseInt(args[1]) < 6) {
                System.out.println("Wrong width value: ( can be only [6, 30] )");
                return false;
            }
        }
        catch (Exception ex){
            System.out.println("Wrong width value: " + ex.getMessage());
            return false;
        }
        return true;
    }

    // checks money from args
    static boolean CheckMoney(String[] args){
        try{
            if( Integer.parseInt(args[2]) > 15000 || Integer.parseInt(args[2]) < 500) {
                System.out.println("Wrong money value: ( can be only [500, 15000] )");
                return false;
            }
        }
        catch (Exception ex){
            System.out.println("Wrong money value: " + ex.getMessage());
            return false;
        }
        return true;
    }

    // return array filled with random nums
    static int[] RandomNumsArray(int lenght, int count){
        int[] arr = new int[count];
        arr[0] = rand.nextInt(lenght - 2);
        for(int i = 1; i < count; i ++){
            arr[i] = rand.nextInt(lenght - 2);
            for(int j = 0; j < i; j++){
                while(arr[i] == arr[j]){
                    arr[i] = rand.nextInt(lenght - 2);
                    j = 0;
                }
            }
        }
        for(int i = 0; i < arr.length; i++){
            arr[i] += 1;
        }
        return arr;
    }

    // prints 2D array
    static void Print2DArray(char[][] array){
        for(int j = 0; j < array.length; j++){
            for(int i = 0 ; i < array[j].length; i++){
                System.out.print(array[j][i]);
            }
            System.out.println();
        }
    }

    // fills empty array chunks with 'X'
    static void FillArray(char[][] array){
        for(int j = 0; j < array.length; j++){
            for(int i = 0 ; i < array[j].length; i++){
                array[j][i] = 'X';
            }
        }
    }

    // creates objField with width and height equal to the field's width and height
    static Cell[][] CreateObjArray(char[][] field){
        Cell[][] objField = new Cell[field.length][field[0].length];
        for(int j = 0; j < field.length; j++){
            for(int i = 0 ; i < field[j].length; i++){
                if (field[j][i] == 'E') {
                    objField[j][i] = new EmptyCell();
                }
                if (field[j][i] == '$') {
                    objField[j][i] = new Bank();
                }
                if (field[j][i] == 'S') {
                    objField[j][i] = new Shop();
                }
                if (field[j][i] == 'T') {
                    objField[j][i] = new Taxi();
                }
                if (field[j][i] == '%'){
                    objField[j][i] = new PenaltyCell();
                }
            }
        }
        return objField;
    }

    // creates field
    static char[][] CreateGameField(int heigh, int width){
        char[][] field = new char[heigh][width];
        FillArray(field);

        // first row
        int numbeOfTaxi = rand.nextInt(3);
        int numberOfPenaltys = rand.nextInt(3);
        while(numbeOfTaxi + numberOfPenaltys + 2 + 1 > field[0].length){
            numbeOfTaxi = rand.nextInt(3);
            numberOfPenaltys = rand.nextInt(3);
        }

        int[] arr = RandomNumsArray(field[0].length, numberOfPenaltys + numbeOfTaxi + 1);

        int counter = 0;
        for(int i = 0 ;i < numberOfPenaltys; i++){
            field[0][arr[counter]] = '%';
            counter ++;
        }
        for(int i = 0; i < numbeOfTaxi; i++){
            field[0][arr[counter]] = 'T';
            counter++;
        }
        field[0][arr[counter]] = '$';

        for(int i = 1; i < field[0].length - 1; i++){
            if(field[0][i] == 'X'){
                field[0][i] = 'S';
            }
        }

        //second row
        numbeOfTaxi = rand.nextInt(3);
        numberOfPenaltys = rand.nextInt(3);
        while(numbeOfTaxi + numberOfPenaltys + 2 + 1 > field[0].length){
            numbeOfTaxi = rand.nextInt(3);
            numberOfPenaltys = rand.nextInt(3);
        }

        arr = RandomNumsArray(field[0].length, numberOfPenaltys + numbeOfTaxi + 1);

        counter = 0;
        for(int i = 0 ;i < numberOfPenaltys; i++){
            field[field.length-1][arr[counter]] = '%';
            counter ++;
        }
        for(int i = 0; i < numbeOfTaxi; i++){
            field[field.length-1][arr[counter]] = 'T';
            counter++;
        }
        field[field.length-1][arr[counter]] = '$';

        for(int i = 1; i < field[0].length - 1; i++){
            if(field[field.length-1][i] == 'X'){
                field[field.length-1][i] = 'S';
            }
        }

        //first column
        numbeOfTaxi = rand.nextInt(3);
        numberOfPenaltys = rand.nextInt(3);
        while(numbeOfTaxi + numberOfPenaltys + 2 + 1 > field.length){
            numbeOfTaxi = rand.nextInt(3);
            numberOfPenaltys = rand.nextInt(3);
        }
        arr = RandomNumsArray(field.length, numberOfPenaltys + numbeOfTaxi + 1);

        counter = 0;
        for(int i = 0 ;i < numberOfPenaltys; i++){
            field[arr[counter]][field[0].length - 1] = '%';
            counter ++;
        }
        for(int i = 0; i < numbeOfTaxi; i++){
            field[arr[counter]][field[0].length - 1] = 'T';
            counter++;
        }
        field[arr[counter]][field[0].length - 1] = '$';

        for(int i = 1; i < field.length-1; i++){
            if(field[i][field[0].length-1] == 'X'){
                field[i][field[0].length-1] = 'S';
            }
        }

        //second column
        numbeOfTaxi = rand.nextInt(3);
        numberOfPenaltys = rand.nextInt(3);
        while(numbeOfTaxi + numberOfPenaltys + 2 + 1 > field.length){
            numbeOfTaxi = rand.nextInt(3);
            numberOfPenaltys = rand.nextInt(3);
        }
        arr = RandomNumsArray(field.length, numberOfPenaltys + numbeOfTaxi + 1);

        counter = 0;
        for(int i = 0 ;i < numberOfPenaltys; i++){
            field[arr[counter]][0] = '%';
            counter ++;
        }
        for(int i = 0; i < numbeOfTaxi; i++){
            field[arr[counter]][0] = 'T';
            counter++;
        }
        field[arr[counter]][0] = '$';

        for(int i = 1; i < field.length-1; i++){
            if(field[i][0] == 'X'){
                field[i][0] = 'S';
            }
        }

        field[0][0] = 'E';
        field[0][field[0].length - 1] = 'E';
        field[field.length - 1][0] = 'E';
        field[field.length - 1][field[0].length - 1] = 'E';

        return field;
    }

    // prints common info
    static void PrintInfo(char[][] field, double creditCoeff, double debtCoeff, double penaltyCoeff){
        Print2DArray(field);
        System.out.println("Credit coeff = " + creditCoeff);
        System.out.println("Debt coeff = " + debtCoeff);
        System.out.println("Penalty coeff = " + penaltyCoeff);
    }

    // defines a cell player appeared on
    static void PlayerDefineCell(Cell[][] objField, Player p, double debtCoeff, double penaltyCoeff, char[][] field, Player bot){
        if(objField[p.y][p.x] instanceof Bank){
            System.out.println("You are in the cell " + p.x + "," + p.y);
            Bank b = (Bank)objField[p.y][p.x];
            System.out.println(b.toString());
            b.OnStep(p, debtCoeff);

        }
        if(objField[p.y][p.x] instanceof Taxi){
            System.out.println("You are in the cell " + p.x + "," + p.y);
            Taxi t = (Taxi) objField[p.y][p.x];
            System.out.println(t.toString());
            t.OnStep(p, field);
        }
        if(objField[p.y][p.x] instanceof Shop){
            Shop s = (Shop) objField[p.y][p.x];
            System.out.println(s.toString());
            s.OnStep(p, bot, field);
        }
        if(objField[p.y][p.x] instanceof PenaltyCell){
            System.out.println("You are in the cell " + p.x + "," + p.y);
            PenaltyCell pen = (PenaltyCell)objField[p.y][p.x];
            System.out.println(pen.toString());
            pen.OnStep(p, penaltyCoeff);
        }
        if(objField[p.y][p.x] instanceof EmptyCell){
            System.out.println("You are in the cell " + p.x + "," + p.y);
            EmptyCell e = (EmptyCell) objField[p.y][p.x];
            System.out.println(e.toString());
        }
    }

    // prints info after the game has ended
    static void EndInfo(Player p, Player bot){
        if(bot.money < 0){
            System.out.println("\nYou have won!");
        }
        else{
            System.out.println("\nBot has won!");
        }
    }

    // defines a cell bot appeared on
    static void BotDefineCell(Cell[][] objField, Player p, double debtCoeff, double penaltyCoeff, char[][] field, Player you){
        if(objField[p.y][p.x] instanceof Bank){
            System.out.println("You are in the cell " + p.x + "," + p.y);
            Bank b = (Bank)objField[p.y][p.x];
            System.out.println("BOT can not use Bank");
        }
        if(objField[p.y][p.x] instanceof Taxi){
            System.out.println("You are in the cell " + p.x + "," + p.y);
            Taxi t = (Taxi) objField[p.y][p.x];
            System.out.println(t.toString());
            t.OnStep(p, field);
        }
        if(objField[p.y][p.x] instanceof Shop){
            Shop s = (Shop) objField[p.y][p.x];
            System.out.println(s.toString());
            s.BotOnStep(p, you, field);
        }
        if(objField[p.y][p.x] instanceof PenaltyCell){
            System.out.println("You are in the cell " + p.x + "," + p.y);
            PenaltyCell pen = (PenaltyCell)objField[p.y][p.x];
            System.out.println(pen.toString());
            pen.OnStep(p, penaltyCoeff);
        }
        if(objField[p.y][p.x] instanceof EmptyCell){
            System.out.println("You are in the cell " + p.x + "," + p.y);
            EmptyCell e = (EmptyCell) objField[p.y][p.x];
            System.out.println(e.toString());
        }
    }

    // gives of a 2 dice's rolls
    static int RollADice(){
        int r1 = rand.nextInt(6) + 1;
        System.out.println("First random num is " + r1);
        int r2 = rand.nextInt(6) + 1;
        System.out.println("Second random num is " + r2);
        return r1+r2;
    }

    // prints info about first player
    static void PlaysFirstInfo(int playsFirst){
        if(playsFirst == 1){
            System.out.println("Player will be first");
        }
        else{
            System.out.println("BOT will be first");
        }
    }

    // bot's act
    static void BotActs(Player bot, char[][] field, Cell[][] objField, double penaltyCoeff, double debtCoeff, Player you){
        System.out.println("\nBOT\n" + "BOT is in the cell " + bot.x + "," + bot.y);
        System.out.println(bot.toString());
        bot.Move(RollADice(), field);
        BotDefineCell(objField, bot, debtCoeff, penaltyCoeff, field, you);
        System.out.println("\nBOT\n" + "BOT is in the cell " + bot.x + "," + bot.y);
        System.out.println(bot.toString());
    }

    // player's act
    static void PlayerActs(Player p, char[][] field, Cell[][] objField, double penaltyCoeff, double debtCoeff, Player bot){
        System.out.println("\nPLAYER\n" + "You are in the cell " + p.x + "," + p.y);
        System.out.println(p.toString());
        p.Move(RollADice(), field);
        PlayerDefineCell(objField, p, debtCoeff, penaltyCoeff, field, bot);
        System.out.println("\nPLAYER\n" + "You are in the cell " + p.x + "," + p.y);
        System.out.println(p.toString());
    }

    static Random rand = new Random();

    public static void main(String[] args) {
        if(args.length > 0){
            // $ - bank
            // S - shop
            // M - player's shop
            // O - bot's shop
            // B - bot
            // P - player
            // E - empty cell
            // T - taxi
            // % - penalty cell
            // X - fill

            // checking args
            if(!(CheckHeight(args) && CheckWidth(args) && CheckMoney(args))){
                System.out.println("return");
                return;
            }

            // initializing fields
            int height = Integer.parseInt(args[0]);
            int width = Integer.parseInt(args[1]);
            int money = Integer.parseInt(args[2]);
            double creditCoeff = 0.002 + (0.2 - 0.002) * rand.nextDouble();
            double debtCoeff = 1 + 2 * rand.nextDouble();
            double penaltyCoeff = 0.01 + (0.1 - 0.01) * rand.nextDouble();
            char[][] field = CreateGameField(height, width);
            Cell[][] objField = CreateObjArray(field);

            // creating players
            Player p = new Player(money);
            Player bot = new Player(money);

            // printing info before the game starts
            PrintInfo(field, creditCoeff, debtCoeff, penaltyCoeff);

            // playsFirst defines who acts first
            int playsFirst = rand.nextInt(2);

            // printing info about player who plays first
            PlaysFirstInfo(playsFirst);

            // game process
            while(p.money >= 0 && bot.money >= 0){
                // if player acts first
                if(playsFirst == 1){
                    PlayerActs(p, field, objField, penaltyCoeff, debtCoeff, bot);
                    Print2DArray(field);
                    BotActs(bot, field, objField, penaltyCoeff, debtCoeff, p);
                    Print2DArray(field);
                }
                // if bot acts first
                else{
                    BotActs(bot, field, objField, penaltyCoeff, debtCoeff, p);
                    Print2DArray(field);
                    PlayerActs(p, field, objField, penaltyCoeff, debtCoeff, bot);
                    Print2DArray(field);
                }
            }

            // gives info about winner
            EndInfo(p, bot);

            System.out.println("\nPLAYER\n" + p.toString());
            System.out.println("\nBOT\n" + bot.toString());


        }
        else{
            System.out.println("No args were provided.");
        }
    }
}
