package com.company;

import java.util.Random;
import java.util.Scanner;

public class Shop extends Cell {
    public static Random rand = new Random();
    int owner; // 0 if no owner // 1 if shop is yours // 2 if shop is bots
    double N;
    double K;
    double compensationCoeff;
    double improvementCoeff;
    public Shop(){
        N = rand.nextInt(451)+50;
        K = (0.5 + 0.4 * rand.nextDouble())*N;
        compensationCoeff = 0.1 + 0.9 * rand.nextDouble();
        improvementCoeff = 0.1 + 1.9 * rand.nextDouble();
    }

    public String toString(){
        return "You are on a ShopCell";
    }

    public void OnStep(Player p, Player bot, char[][] field) {
        Scanner in = new Scanner(System.in);
        if(owner == 1){
            if(p.money < improvementCoeff * N){
                System.out.println("You don't have enough money for upgrade");
            }
            else{
                System.out.println("You are in your shop " + p.x + "," + p.y + "\nWould you like to upgrade it for "
                        + improvementCoeff * N + "$\nInput ‘Yes’ if you agree or ‘No’ otherwise");
                String answer = in.nextLine();
                while(!answer.equals("Yes") && !answer.equals("No")){
                    System.out.println("Wrong input print rather Yes or No");
                    answer = in.nextLine();
                }
                if(answer.equals("yes")){
                    System.out.println("You have upgraded shop for " + improvementCoeff * N);
                    N = N + improvementCoeff * N;
                    K = K + compensationCoeff * K;
                    p.money -= improvementCoeff * N;
                    p.moneySpend += improvementCoeff * N;
                }
            }
        }
        if (owner == 0) {
            if(p.money < N){
                System.out.println("You don't have enough money to buy this shop.");
                return;
            }
            System.out.println("You are in " + p.x + "," + p.y + " This shop has no owner. Would you like to buy it for " + N
                    + "$\nInput 'Yes' if you agree or 'No' otherwise.");
            String answer = in.nextLine();
            while(!answer.equals("Yes") && !answer.equals("No")){
                System.out.println("Wrong input print rather Yes or No");
                answer = in.nextLine();
            }
            if (answer.equals("Yes")) {
                owner = 1;
                p.money -= N;
                p.moneySpend += N;
                System.out.println("You have successfully bought a shop for " + N);
                field[p.y][p.x] = 'M';
            }
            if (answer.equals("No")) {
                System.out.println("Well... maybe next time");
                return;
            }
        }
        if(owner == 2){
            if(p.money < K){
                System.out.println("You don't have enough money to pay compensation " + K +  " The game is over");
            }
            else{
                System.out.println("You have payed the compensation " + K);
                p.money -= K;
                bot.money += K;
            }
        }
    }

    public void BotOnStep(Player p, Player you, char[][] field) {
        if(owner == 2){
            if(p.money < improvementCoeff * N){
                System.out.println("BOT don't have enough money for upgrade");
            }
            else{
                System.out.println("You are in your shop " + p.x + "," + p.y + "\nWould you like to upgrade it for "
                        + improvementCoeff * N + "$\nInput ‘Yes’ if you agree or ‘No’ otherwise");
                if(rand.nextInt(2) == 1){
                    System.out.println("BOT have upgraded shop for " + improvementCoeff * N);
                    N = N + improvementCoeff * N;
                    K = K + compensationCoeff * K;
                    p.money -= improvementCoeff * N;
                    p.moneySpend += improvementCoeff * N;
                }
            }
        }
        if (owner == 0) {
            if(p.money < N){
                System.out.println("BOT don't have enough money to buy this shop.");
                return;
            }
            System.out.println("You are in " + p.x + "," + p.y + " This shop has no owner. Would you like to buy it for " + N
                    + "$\nInput 'Yes' if you agree or 'No' otherwise.");
            if (rand.nextInt(2) == 1) {
                owner = 2;
                p.money -= N;
                p.moneySpend += N;
                System.out.println("BOT have successfully bought a shop for " + N);
                field[p.y][p.x] = 'O';
            }
            else{
                System.out.println("Well... maybe next time");
                return;
            }
        }
        if(owner == 1){
            if(p.money < K){
                System.out.println("BOT don't have enough money to pay compensation " + K +  " The game is over");
            }
            else{
                System.out.println("BOT have payed the compensation " + K);
                p.money -= K;
                you.money += K;
            }
        }
    }
}
