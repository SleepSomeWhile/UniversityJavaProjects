package com.company;

public class Player {
    public Player(int money){
        this.money = money;
        pos = 0;
    }

    public String toString(){
        return  "Money = " + money + "\n" + "Debt = " + debt + "\n" + "Money spend = " + moneySpend + "\n";
    }
    public void Move(int range, char[][] field){
        pos += range;
        int width = field[0].length;
        int height = field.length;
        pos = pos % (width * 2 + height * 2 - 4);
        if (pos <= width - 1){
            System.out.println("");
          y = 0;
          x = pos;
        }
        if (pos > width - 1 && pos <= (width + height - 2) ){
            System.out.println("");
            y = pos - width + 1;
            x = width - 1;
        }
        if (pos > (width + height - 2) && pos <= (2 * width + height -3)){
            System.out.println("");
            y = height - 1;
            x = width - 1 - (pos % (width+height-2));
        }
        if (pos > (2 * width + height -3) && pos <= (2 * width + 2 * height - 4) ){
            x = 0;
            y = (height - 1) - (pos % (width * 2 - 3 + height));
        }
    }
    public
    double moneySpend;
    double debt;
    int pos;
    int x;
    int y;
    String name;
    int money;
}
