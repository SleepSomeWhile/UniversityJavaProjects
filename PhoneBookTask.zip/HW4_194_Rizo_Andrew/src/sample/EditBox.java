package sample;

import Classes.Person;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class EditBox {

    static TextField nameInput, surnameInput, otchestvoInput, phoneNumberInput, adressInput, birthDateInput, commentInput;

    static Person p;

    static TableView<Person> table;

    static DatePicker datePicker;

    static Stage window;

    public static void display(String title, TableView<Person> tableee, Person pers){
        p = pers;
        table = tableee;
        window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        window.setMinWidth(300);
        window.setMinWidth(600);


        nameInput = new javafx.scene.control.TextField();
        nameInput.setPromptText(p.getName());
        nameInput.appendText(p.getName());
        nameInput.setMinWidth(60);

        surnameInput = new javafx.scene.control.TextField();
        surnameInput.setPromptText(p.getSurname());
        surnameInput.appendText(p.getSurname());
        surnameInput.setMinWidth(60);

        otchestvoInput = new javafx.scene.control.TextField();
        otchestvoInput.setPromptText(p.getOtchestvo());
        otchestvoInput.appendText(p.getOtchestvo());
        otchestvoInput.setMinWidth(60);

        phoneNumberInput = new javafx.scene.control.TextField();
        phoneNumberInput.setPromptText(p.getPhoneNumber());
        phoneNumberInput.appendText(p.getPhoneNumber());
        phoneNumberInput.setMinWidth(100);

        adressInput = new javafx.scene.control.TextField();
        adressInput.setPromptText(p.getAdress());
        adressInput.appendText(p.getAdress());
        adressInput.setMinWidth(100);


        datePicker = new DatePicker();
        datePicker.setValue(LocalDate.of(2030, 1, 1));
        datePicker.setShowWeekNumbers(true);

        /*birthDateInput = new javafx.scene.control.TextField();
        birthDateInput.setPromptText(p.getBirthDate());
        birthDateInput.appendText(p.getBirthDate());
        birthDateInput.setMinWidth(100);*/

        commentInput = new javafx.scene.control.TextField();
        commentInput.setPromptText(p.getComment());
        commentInput.appendText(p.getComment());
        commentInput.setMinWidth(500);

        Button editButton = new Button("Изменить");
        editButton.setOnAction(e -> addButtonclicked());

        Button returnButton = new Button("Отмена");
        returnButton.setOnAction(e -> returnButtonclicked());

        HBox lowerBox = new HBox();
        lowerBox.setPadding(new Insets(10,10,10,10));
        lowerBox.setSpacing(10);
        lowerBox.getChildren().addAll(returnButton, editButton);

        VBox layout = new VBox(10);
        layout.getChildren().addAll(nameInput, surnameInput, otchestvoInput, phoneNumberInput, adressInput, datePicker, commentInput, lowerBox);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    private static void addButtonclicked(){
        ObservableList<Person> personSelected, allPersosns;
        allPersosns = table.getItems();
        Person newP = new Person();

        newP.setName(nameInput.getText());
        newP.setSurname(surnameInput.getText());
        newP.setOtchestvo(otchestvoInput.getText());
        newP.setPhoneNumber(phoneNumberInput.getText());
        newP.setAdress(adressInput.getText());
        if(datePicker.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")).equals("2030-01-01")){
            newP.setBirthDate("");
        }
        else{
            newP.setBirthDate(datePicker.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        }
        newP.setComment(commentInput.getText());

        if(Checker.Check(newP)){

            allPersosns.remove(p);
            Main.personsInTable.remove(p);
            allPersosns.add(newP);
            Main.personsInTable.add(newP);
            p = newP;

            nameInput.clear();
            surnameInput.clear();
            otchestvoInput.clear();
            phoneNumberInput.clear();
            adressInput.clear();
            //birthDateInput.clear();
            commentInput.clear();
        }
        else{
            nameInput.clear();
            surnameInput.clear();
            otchestvoInput.clear();
            phoneNumberInput.clear();
            adressInput.clear();
            //birthDateInput.clear();
            commentInput.clear();
        }

    }

    private static void returnButtonclicked(){
        window.close();
    }
}