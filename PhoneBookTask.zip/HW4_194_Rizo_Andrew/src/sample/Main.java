package sample;
import Classes.Person;
import javafx.application.Application;
import javafx.beans.InvalidationListener;
import javafx.collections.ListChangeListener;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.FlowPane;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.geometry.Orientation;

import javafx.beans.value.ObservableValue;
import javafx.beans.value.ChangeListener;
import javafx.stage.Window;

import java.io.*;
import java.util.*;

public class Main extends Application{

    static Stage window;

    static TableView<Person> table;

    static ArrayList<Person> personsInTable;

    public static void main(String[] args) {

        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        personsInTable = new ArrayList<>();

        window = primaryStage;
        window.setTitle("Телефонная книга");
        window.setOnCloseRequest(e -> BeforeClosing(personsInTable));

        //name column
        TableColumn<Person, String> nameColumn = new TableColumn<>("Имя");
        nameColumn.setMinWidth(100);
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        //surname column
        TableColumn<Person, String> surnameColumn = new TableColumn<>("Фамилия");
        surnameColumn.setMinWidth(100);
        surnameColumn.setCellValueFactory(new PropertyValueFactory<>("surname"));

        //otchestvo column
        TableColumn<Person, String> otchestvoColumn = new TableColumn<>("Отчество");
        otchestvoColumn.setMinWidth(100);
        otchestvoColumn.setCellValueFactory(new PropertyValueFactory<>("otchestvo"));

        //phoneNumber column
        TableColumn<Person, String> phoneNumberColumn = new TableColumn<>("Мобильный / Домашний телефон");
        phoneNumberColumn.setMinWidth(100);
        phoneNumberColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));

        //adress column
        TableColumn<Person, String> adressColumn = new TableColumn<>("Адрес");
        adressColumn.setMinWidth(100);
        adressColumn.setCellValueFactory(new PropertyValueFactory<>("adress"));

        //birthDate column
        TableColumn<Person, String> birthDateColumn = new TableColumn<>("День Рождения");
        birthDateColumn.setMinWidth(200);
        birthDateColumn.setCellValueFactory(new PropertyValueFactory<>("birthDate"));

        //comment column
        TableColumn<Person, String> commentColumn = new TableColumn<>("Комментарий");
        commentColumn.setMinWidth(200);
        commentColumn.setCellValueFactory(new PropertyValueFactory<>("comment"));

        TextField searchInput = new TextField();
        searchInput.setPromptText("Поиск");
        searchInput.setMinWidth(100);

        //button
        Button addButton = new Button("Добавить");
        addButton.setOnAction(e -> addButtonclicked());
        Button deleteButton = new Button("Удалить");
        deleteButton.setOnAction(e -> deleteButtonclicked());
        Button fileButton = new Button("Файл");
        Button settingsButton = new Button("Настройки");
        Button editButton = new Button("Редактировать");
        editButton.setOnAction(e -> editButtonclicked());
        Button infoButton = new Button("Справка");
        Button findButton = new Button("Найти");
        findButton.setOnAction(e -> searchButtonclicked(searchInput.getText()));


        /*HBox upperBox = new HBox();
        upperBox.setPadding(new Insets(10,10,10,10));
        upperBox.setSpacing(10);
        upperBox.getChildren().addAll(fileButton, settingsButton, infoButton);*/

        HBox lowerBox = new HBox();
        lowerBox.setPadding(new Insets(10,10,10,10));
        lowerBox.setSpacing(10);
        lowerBox.getChildren().addAll(deleteButton, editButton, addButton, searchInput, findButton);


        table = new TableView<>();
        table.setItems(getPerson());
        table.getColumns().addAll(nameColumn, surnameColumn, otchestvoColumn, phoneNumberColumn, adressColumn, birthDateColumn, commentColumn);


        MenuItem addContact = new MenuItem("Добавить новый контакт");
        addContact.setOnAction(e -> addButtonclicked());

        MenuItem editContact = new MenuItem("Редактирование");
        editContact.setOnAction(e -> editButtonclicked());

        MenuItem deleteContact = new MenuItem("Удалить контакт");
        deleteContact.setOnAction(e -> deleteButtonclicked());

        MenuItem exit = new MenuItem("Выход");
        exit.setOnAction(e -> exitButtonclicked());


        Menu fileMenu = new Menu("Файл");
        fileMenu.getItems().addAll(addContact, editContact, deleteContact, new SeparatorMenuItem(), exit);

        Menu settingsMenu = new Menu("Настройки");
        settingsMenu.getItems().addAll(new MenuItem("Импортировать"), new MenuItem("Экспортировать"));

        Menu infoMenu = new Menu("Справка");
        infoMenu.getItems().addAll(new MenuItem("БПИ194 Ризо Андрей \n импорт / экспорт не реализованы :( \n номер телефона обязательно начинается с '+' "));

       MenuBar upperMenuBar = new MenuBar();
       upperMenuBar.getMenus().addAll(fileMenu, settingsMenu, infoMenu);

        VBox vBox = new VBox();
        vBox.getChildren().addAll(upperMenuBar, table, lowerBox);

        Scene scene = new Scene(vBox);
        window.setScene(scene);
        window.show();
    }


    public void addButtonclicked(){

        AddBox.display("Добавление записи", table);
    }

    public void editButtonclicked(){
        ObservableList<Person> personSelected, allPersosns;
        allPersosns = table.getItems();
        personSelected = table.getSelectionModel().getSelectedItems();

        try{
            for (Person p: personSelected) {
                EditBox.display("Редактирование записи", table, p);
            }
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }

    }

    public void searchButtonclicked(String request){
        // при пустом запросе возвращаем всю таблицу
        table.getItems().clear();

        for(int i = 0; i< personsInTable.size(); i++){
            table.getItems().add(personsInTable.get(i));
        }

        if(request.equals("")){
            return;
        }

        ObservableList<Person> dataFromTable = table.getItems();


        for(int i = 0; i < dataFromTable.size(); i++){
            if(dataFromTable.get(i).getName().contains(request) || dataFromTable.get(i).getSurname().contains(request) || dataFromTable.get(i).getOtchestvo().contains(request)){

            }
            else{
                dataFromTable.remove(dataFromTable.get(i));
                i--;
            }
        }
    }

    public void deleteButtonclicked(){
        ObservableList<Person> personSelected, allPersosns;
        allPersosns = table.getItems();
        personSelected = table.getSelectionModel().getSelectedItems();

        for (Person p: personSelected) {
            personsInTable.remove(p);
            allPersosns.remove(p);
        }
    }

    public ObservableList<Person> getPerson(){
        ObservableList<Person> products = FXCollections.observableArrayList();
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("table.dat")))
        {

            personsInTable=((ArrayList<Person>)ois.readObject());
        }
        catch(Exception ex){

            System.out.println(ex.getMessage());
        }
        for(int i = 0; i < personsInTable.size(); i++){
            products.add(personsInTable.get(i));
        }
        return products;

    }

    public void exitButtonclicked(){
        BeforeClosing(personsInTable);
    }

    public void BeforeClosing(ArrayList<Person> list){
        System.out.println("closing");
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("table.dat")))
        {
            oos.writeObject(list);
            System.out.println("File has been written");
        }
        catch(Exception ex){

            System.out.println(ex.getMessage());
        }
    }

    public void Export(ArrayList<Person> list, String path){
        try{
            System.out.println("closing");
            try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("table.dat")))
            {
                oos.writeObject(list);
                System.out.println("File has been written");
            }
            catch(Exception ex){

                System.out.println(ex.getMessage());
            }
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

}