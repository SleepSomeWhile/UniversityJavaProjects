package sample;

import Classes.Person;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class AddBox {

    static TextField nameInput, surnameInput, otchestvoInput, phoneNumberInput, adressInput, birthDateInput, commentInput;

    static DatePicker datePicker;

    static TableView<Person> table;

    static Stage window;

    public static void display(String title, TableView<Person> tableee){
        table = tableee;
        window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        window.setMinWidth(300);
        window.setMinWidth(600);

        nameInput = new javafx.scene.control.TextField();
        nameInput.setPromptText("Имя");
        nameInput.setMinWidth(60);

        surnameInput = new javafx.scene.control.TextField();
        surnameInput.setPromptText("Фамилия");
        surnameInput.setMinWidth(60);

        otchestvoInput = new javafx.scene.control.TextField();
        otchestvoInput.setPromptText("Отчество");
        otchestvoInput.setMinWidth(60);

        phoneNumberInput = new javafx.scene.control.TextField();
        phoneNumberInput.setPromptText("Мобильный / Домашний телефон");
        phoneNumberInput.setMinWidth(100);

        adressInput = new javafx.scene.control.TextField();
        adressInput.setPromptText("Адрес");
        adressInput.setMinWidth(100);


        datePicker = new DatePicker();
        datePicker.setValue(LocalDate.of(2030, 1, 1));
        datePicker.setShowWeekNumbers(true);
        /*birthDateInput = new javafx.scene.control.TextField();
        birthDateInput.setPromptText("День Рождения");
        birthDateInput.setMinWidth(100);*/

        commentInput = new javafx.scene.control.TextField();
        commentInput.setPromptText("Комментарий");
        commentInput.setMinWidth(500);

        Button addButton = new Button("Добавить");
        addButton.setOnAction(e -> addButtonclicked());

        Button returnButton = new Button("Отмена");
        returnButton.setOnAction(e -> returnButtonclicked());

        HBox lowerBox = new HBox();
        lowerBox.setPadding(new Insets(10,10,10,10));
        lowerBox.setSpacing(10);
        lowerBox.getChildren().addAll(returnButton, addButton);

        VBox layout = new VBox(10);
        layout.getChildren().addAll(nameInput, surnameInput, otchestvoInput, phoneNumberInput, adressInput, datePicker, commentInput, lowerBox);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    private static void returnButtonclicked(){
        window.close();
    }

    private static void addButtonclicked(){
        Person p = new Person();
        p.setName(nameInput.getText());
        p.setSurname(surnameInput.getText());
        p.setOtchestvo(otchestvoInput.getText());
        p.setPhoneNumber(phoneNumberInput.getText());
        p.setAdress(adressInput.getText());
        if(datePicker.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")).equals("2030-01-01")){
            p.setBirthDate("");
        }
        else{
            p.setBirthDate(datePicker.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        }
        p.setComment(commentInput.getText());
        if(Checker.Check(p)){
            table.getItems().add(p);
            Main.personsInTable.add(p);
            System.out.println(Main.personsInTable.size());
            nameInput.clear();
            surnameInput.clear();
            otchestvoInput.clear();
            phoneNumberInput.clear();
            adressInput.clear();
            commentInput.clear();
        }
        else{
            nameInput.clear();
            surnameInput.clear();
            otchestvoInput.clear();
            phoneNumberInput.clear();
            adressInput.clear();
            commentInput.clear();
        }

    }
}
