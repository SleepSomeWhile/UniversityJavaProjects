package sample;

import Classes.Person;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Checker {

    public static boolean Check(Person p){
        if(!checkName(p)){
            return false;
        }
        if(!checkSurname(p)){
            return false;
        }
        if(!checkOtchestvo(p)){
            return false;
        }
        if(!checkNumber(p)){
            return false;
        }
        if(!checkAdress(p)){
            return false;
        }
        /*if(!checkBirthDate(p)){
            System.out.println("birth date");
            return false;
        }*/
        if(!checkComment(p)){
            return false;
        }
        return true;
    }

    // фимилия может быть любой но не может содержать цифры
    public static boolean checkName(Person p){
        int length = p.getName().length();
        if(length < 1){
            return false;
        }
        for(int i = 0; i < length; i++){
            if(p.getName().charAt(i) >= '0' && p.getName().charAt(i) <= '9'){
                return false;
            }
        }
        return true;
    }


    // фимилия может быть любой но не может содержать цифры
    public static boolean checkSurname(Person p){
        int length = p.getSurname().length();
        if(length < 1){
            return false;
        }
        for(int i = 0; i < length; i++){
            if(p.getSurname().charAt(i) >= '0' && p.getSurname().charAt(i) <= '9'){
                return false;
            }
        }
        return true;
    }

    // отчество может быть любым но не может содержать цифры
    public static boolean checkOtchestvo(Person p){
        int length = p.getOtchestvo().length();
        for(int i = 0; i < length; i++){
            if(p.getOtchestvo().charAt(i) >= '0' && p.getOtchestvo().charAt(i) <= '9'){
                return false;
            }
        }
        return true;
    }

    // формат +(цифры)
    public static boolean checkNumber(Person p){
        int length = p.getPhoneNumber().length();
        if(length < 2){
            return false;
        }
        if(p.getPhoneNumber().charAt(0) != '+'){
            return false;
        }
        for(int i = 1; i < length; i++){
            if(p.getPhoneNumber().charAt(i) >= '0' && p.getPhoneNumber().charAt(i) <= '9'){

            }
            else{
                return false;
            }
        }
        return true;
    }

    // ограничение только на длинну или пустое поле, или длинна >= 2
    public static boolean checkAdress(Person p){
        if(p.getAdress().equals("")){
            return true;
        }
        if(p.getAdress().length() <= 2){
            return false;
        }
        return true;
    }

    // пример корректной даты 11.11.1111
    /*public static boolean checkBirthDate(Person p){
        try{
            Date date=new SimpleDateFormat("dd.MM.yyyy").parse(p.getBirthDate());
        }catch(Exception e){
            return false;
        }
        return true;
    }*/

    public static boolean checkComment(Person p){
        return true;
    }

}
