package Classes;
import javafx.beans.property.*;

import java.io.Serializable;
import java.util.Date;


public class Person implements Serializable {

    private String name;
    private String surname;
    private String otchestvo;
    private String phoneNumber;
    private String adress;
    private String birthDate;
    private String comment;

    public Person(String name, String surname, String otchestvo, String phoneNumber, String adress, String birthDate, String comment){
        this.name = name;
        this.surname = surname;
        this.otchestvo = otchestvo;
        this.phoneNumber = phoneNumber;
        this.adress = adress;
        this.birthDate = birthDate;
        this.comment = comment;
    }

    public Person(){
        name = "";
        surname = "";
        otchestvo = "";
        phoneNumber = "";
        adress = "";
        birthDate = "";
        comment = "";
    }

    public String getName(){ return name;}
    public void setName(String value){ name = value;}

    public String getSurname(){ return surname;}
    public void setSurname(String value){ surname = value;}

    public String getOtchestvo(){ return otchestvo;}
    public void setOtchestvo(String value){ otchestvo = value;}

    public String getPhoneNumber(){ return phoneNumber;}
    public void setPhoneNumber(String value){ phoneNumber = value;}

    public String getAdress(){ return adress;}
    public void setAdress(String value){ adress = value;}

    public String getBirthDate(){ return birthDate;}
    public void setBirthDate(String value){ birthDate = value;}

    public String getComment(){ return comment;}
    public void setComment(String value){ comment = value;}
}

