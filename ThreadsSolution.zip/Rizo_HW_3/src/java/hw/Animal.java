package hw;

import java.util.Random;

public class Animal extends Thread {
    public static Random rand = new Random();

    Telega telega;
    long millis;

    private int s;
    public int GetS(){
        return s;
    }

    private int sleepTime;
    public int GetSleepTime(){
        return sleepTime;
    }

    private int Angle;
    public int GetAngle(){
        return Angle;
    }

    private String Name;

    public Animal(String name, Telega telega, int angle){
        s = rand.nextInt(9) + 1;
        sleepTime = rand.nextInt(4000) + 1000;
        Name = name;
        this.telega = telega;
        this.millis = System.currentTimeMillis();
        this.Angle = angle;
    }

    public void run(){
        while(true){
            try {
                if(System.currentTimeMillis() - this.millis > 25000){
                    System.out.println(this.ToString() + " has stopped his work after "
                            + (System.currentTimeMillis() - this.millis)/1000. + " sec");
                    return;
                }
                telega.Moove(this);
                Thread.sleep(sleepTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public String ToString(){
        return "Name: " + Name + " S parameter: " + s;
    }
}
