package hw;

import java.util.Random;

public class Main {

    public static void PrintInfo(Telega telega){
        String formattedX = String.format("%.2f", telega.GetX());
        String formattedY = String.format("%.2f", telega.GetY());
        System.out.println("X coordinate: " + formattedX + " | " + "Y coordinate: " + formattedY);
    }

    public static Random rand = new Random();

    public static void main(String[] args) {

        Telega telega;

        if(args.length != 2){
            System.out.println("Wrong args for telega creation. Start x and y will be 0 | 0");
            telega = new Telega(0, 0);
        }
        else{
            telega = new Telega(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
        }

        Animal lobster = new Animal("Lobster", telega, 180);
        Animal pike = new Animal("Pike", telega, 300);
        Animal swan = new Animal("Swan", telega, 60);

        lobster.start();
        pike.start();
        swan.start();

        long millis = System.currentTimeMillis();

        while(swan.isAlive() || lobster.isAlive() || pike.isAlive()){
            if(System.currentTimeMillis() - millis > 2000){
                PrintInfo(telega);
                millis = System.currentTimeMillis();
            }
        }

        System.out.println("All animals have died :( Final coordinates of telega are:");
        PrintInfo(telega);
    }
}