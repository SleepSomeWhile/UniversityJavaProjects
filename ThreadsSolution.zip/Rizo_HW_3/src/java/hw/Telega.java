package hw;

public class Telega{

    private double x;
    public double GetX(){
        return x;
    }

    private double y;
    public double GetY(){
        return y;
    }

    synchronized public void Moove(Animal animal){
        x = x + animal.GetS()*Math.cos(animal.GetAngle()*3.14/180);
        y = y + animal.GetS()*Math.sin(animal.GetAngle()*3.14/180);
    }

    public Telega(int x, int y){
        this.x = x;
        this.y = y;
    }
}
