package hw;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void test_GetS(){
        Telega t = new Telega(5,5);
        Animal a = new Animal("AnimalName", t, 0);
        int x = a.GetS();
        boolean result;
        if(x >= 1 && x <10){
            result = true;
        }
        else{
            result = false;
        }
        assertEquals(true, result);
    }


    @Test
    void test_GetAngle(){

        Telega t = new Telega(5,5);
        Animal a = new Animal("AnimalName", t, 0);
        assertEquals(0, a.GetAngle());
    }

    @Test
    void test_GetSleepTime(){

        Telega t = new Telega(5,5);
        Animal a = new Animal("AnimalName", t, 0);
        int x = a.GetSleepTime();
        boolean result;
        if(x >= 1000 && x < 5000){
            result = true;
        }
        else{
            result = false;
        }
        assertEquals(true, result);
    }


    @Test
    void test_Run(){

        Telega t = new Telega(5,5);
        Animal a = new Animal("AnimalName", t, 0);
        a.start();
        a.interrupt();
    }

    @Test
    void test_TelegaGetXGetY(){

        Telega t = new Telega(5,6);
        Animal a = new Animal("AnimalName", t, 0);
        assertEquals(5,t.GetX());
        assertEquals(6,t.GetY());
    }

    @Test
    void test_ToString(){

        Telega t = new Telega(5,6);
        Animal a = new Animal("AnimalName", t, 0);
        System.out.println(a.ToString());
    }
}
